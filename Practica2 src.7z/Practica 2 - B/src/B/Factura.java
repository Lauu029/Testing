package B;

public interface Factura {

}
