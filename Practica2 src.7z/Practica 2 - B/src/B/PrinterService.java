package B;

public interface PrinterService {

	void printFactura(Factura factura);
	
}
