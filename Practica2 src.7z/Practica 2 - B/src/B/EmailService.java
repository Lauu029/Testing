package B;

public interface EmailService {

	void sendFactura(Factura factura, String email);
}
