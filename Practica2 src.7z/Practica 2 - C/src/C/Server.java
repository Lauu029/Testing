package C;

public interface Server {
	public Result connect(Web web);
}
