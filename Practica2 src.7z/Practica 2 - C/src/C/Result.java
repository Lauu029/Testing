package C;

public interface Result {
	
	public Boolean isOk();
}
