package C;

public interface Web {

}
