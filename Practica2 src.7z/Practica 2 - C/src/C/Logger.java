package C;

public interface Logger {
	
	public void registerWebReturnedError(Web web,Result result);
	public void registerWebisOk(Web web);
}
