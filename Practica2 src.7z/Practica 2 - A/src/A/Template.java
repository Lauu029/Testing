package A;

public interface Template {

}
