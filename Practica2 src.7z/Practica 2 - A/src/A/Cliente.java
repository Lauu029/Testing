package A;

public interface Cliente {

	String getEmail();
}
