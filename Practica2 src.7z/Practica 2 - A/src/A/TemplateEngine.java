package A;

public interface TemplateEngine {
	
	String preparaMensaje(Template template, Cliente cliente);
	
}
