package A;

public interface MailServer {

	void send(String email, String contenido);
}
